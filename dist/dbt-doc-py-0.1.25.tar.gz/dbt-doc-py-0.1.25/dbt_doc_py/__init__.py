from dbt_doc_py.dbt_doc_py import run_async_main

if __name__ == "__main__":
    run_async_main()
